import pygame
import asyncio
import random

# --- Settings ---
WIDTH, HEIGHT = 800, 600
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
CYAN = (0, 255, 255)

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pygbag Build Test")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 32)

    bg_color = BLACK
    circle_pos = [WIDTH // 2, HEIGHT // 2]
    click_count = 0

    running = True
    while running:
        # 1. Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Interaction Test (Click or Tap)
            if event.type == pygame.MOUSEBUTTONDOWN:
                bg_color = (random.randint(0, 100), random.randint(0, 100), random.randint(0, 100))
                click_count += 1
                circle_pos = list(event.pos)

        # Keyboard Test
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:  circle_pos[0] -= 5
        if keys[pygame.K_RIGHT]: circle_pos[0] += 5
        if keys[pygame.K_UP]:    circle_pos[1] -= 5
        if keys[pygame.K_DOWN]:  circle_pos[1] += 5

        # 2. Drawing
        screen.fill(bg_color)

        # Display Information
        txt1 = font.render("Pygbag Build Test", True, WHITE)
        txt2 = font.render(f"Clicks/Taps: {click_count}", True, WHITE)
        txt3 = font.render("Action: Click to change color", True, WHITE)
        txt4 = font.render("Arrow keys to move circle", True, WHITE)

        screen.blit(txt1, (20, 20))
        screen.blit(txt2, (20, 70))
        screen.blit(txt3, (20, 120))
        screen.blit(txt4, (20, 170))

        pygame.draw.circle(screen, CYAN, circle_pos, 40)

        pygame.display.flip()

        # 3. Required for Pygbag
        await asyncio.sleep(0)
        clock.tick(FPS)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())